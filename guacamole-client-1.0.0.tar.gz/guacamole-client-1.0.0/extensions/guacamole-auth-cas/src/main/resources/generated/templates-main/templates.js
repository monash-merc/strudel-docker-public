angular.module('templates-main', ['app/ext/guac-cas/templates/casTicketField.html']);

angular.module('app/ext/guac-cas/templates/casTicketField.html', []).run(['$templateCache', function($templateCache) {
	$templateCache.put('app/ext/guac-cas/templates/casTicketField.html',
	"<div class=\"cas-ticket-field-container\">\n" +
	"    <div class=\"cas-ticket-field\">\n" +
	"        <p>{{ 'LOGIN.INFO_CAS_REDIRECT_PENDING' | translate }}</p>\n" +
	"    </div>\n" +
	"</div>");
}]);

