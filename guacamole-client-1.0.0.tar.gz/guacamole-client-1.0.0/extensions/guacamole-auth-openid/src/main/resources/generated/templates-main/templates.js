angular.module('templates-main', ['app/ext/guac-openid/templates/openidTokenField.html']);

angular.module('app/ext/guac-openid/templates/openidTokenField.html', []).run(['$templateCache', function($templateCache) {
	$templateCache.put('app/ext/guac-openid/templates/openidTokenField.html',
	"<div class=\"openid-token-field-container\">\n" +
	"    <div class=\"openid-token-field\">\n" +
	"        <p>{{ 'LOGIN.INFO_REDIRECT_PENDING' | translate }}</p>\n" +
	"    </div>\n" +
	"</div>");
}]);

